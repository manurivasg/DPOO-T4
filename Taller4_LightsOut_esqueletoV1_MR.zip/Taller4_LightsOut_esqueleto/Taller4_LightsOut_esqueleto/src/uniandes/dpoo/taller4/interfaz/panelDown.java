package uniandes.dpoo.taller4.interfaz;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class panel_down extends JPanel {
	
	private Integer jugadas;
	private String usuario;
	private ventana_principal vp;
	
	private JLabel label_jugadas;
	private JLabel label_jugador;
	private JLabel l_jugadas;
	private JLabel l_jugador;
	
	public panel_down(ventana_principal vp) {
		this.vp = vp;
		this.usuario = vp.getUsuario();
		

		jugadas = 0;
	
		
		setLayout(new GridLayout(1,4));
		
		label_jugadas = new JLabel("Jugadas:");
		add(label_jugadas);
		
		l_jugadas = new JLabel(jugadas.toString());
		add(l_jugadas);
		
		label_jugador = new JLabel("Jugador");
		add(label_jugador);
		
		l_jugador = new JLabel(usuario);
		add(l_jugador);
	}
	
	public void sumar_jugada() {
		
		jugadas += 1;
		l_jugadas.setText(jugadas.toString());

	}
	
	public void reiniciar_jugadas() {
		jugadas = 0;
		l_jugadas.setText(jugadas.toString());
	}
	
	public void cambiar_jugador() {
		l_jugador.setText(vp.getUsuario());
	}
	

}
