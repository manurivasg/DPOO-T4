package uniandes.dpoo.taller4.interfaz;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

import uniandes.dpoo.taller4.modelo.Tablero;

public class ventana_principal extends JFrame {
	
	private Tablero modelo;
	
	private panel_up panel_up;
	private panel_right panel_right;
	private panel_down panel_down;
	private panel_left panel_left;
	private String usuario;
	
	private int tamano;
	private String dificultad;
	
	public ventana_principal() {
		
		tamano = 5;
		dificultad = "Facil"; 

		setLayout(new BorderLayout());
        setSize( 900, 580 );
        setResizable( true );
        setDefaultCloseOperation( WindowConstants.DISPOSE_ON_CLOSE );
        setTitle( "Lights out" );
        
        panel_right = new panel_right(this);
        add(panel_right, BorderLayout.EAST);
        
        
        panel_up = new panel_up(this);
        add(panel_up,BorderLayout.NORTH);
        
    	panel_left = new panel_left(null,this);
		add(panel_left,BorderLayout.CENTER);
		
		String mensaje =JOptionPane.showInputDialog("Bienvenido.\n"
				+ "Para iniciar, ingresa un nombre de usuario.\n"
				+ "Luego, selecciona un tamaño de tablero y  dificultad.\n");
		
		while (mensaje.equals("")) {
			mensaje = JOptionPane.showInputDialog("Ingresa por favor un nombre de usuario");
		}
		usuario = mensaje;
		
        panel_down = new panel_down(this);
        add(panel_down, BorderLayout.SOUTH);
        
	}
	
	
	public void nuevo_tablero() {
		tamano = panel_up.getTamano_selecionado();
		modelo = new Tablero(tamano);
		
		dificultad = panel_up.getDificultad_seleccionada();
		int desorden = 0;
		if (dificultad.equals("Facil")) desorden = 5;
		if (dificultad.equals("Medio")) desorden = 10;
		if (dificultad.equals("Dificil")) desorden = 15;
		modelo.desordenar(desorden);
		panel_left.nuevo_tablero(modelo.darTablero());
		
	}
	
	public void jugar(int fila, int columna) {
		modelo.jugar(fila, columna);
		panel_down.sumar_jugada();
		panel_left.repaint();
		
		if (modelo.tableroIluminado()) {
			terminar_juego();
		}
	}
	
	public int getTamano(){
		return tamano;
	}
	
	public int getJugadas() {
		return modelo.darJugadas();
	}
	
	public void reiniciar() {
		if (modelo != null) {
		modelo.reiniciar();
		panel_left.repaint();
		panel_down.reiniciar_jugadas();
		}
	}
	
	public void cambiar_jugador() {
		
		String mensaje = JOptionPane.showInputDialog("Ingrese un nombre de usuario");
		usuario = mensaje;
		panel_down.cambiar_jugador();
		
	}
	
	public String getUsuario() {
		return usuario;
	}
	
	public void terminar_juego() {
		
		Integer puntaje = (Integer)modelo.calcularPuntaje();
		String[] opciones = {"Nuevo Juego"};
		int n = JOptionPane.showOptionDialog(this, "¡Lo has lorado!.\n"
				+ "Tu puntaje fue de: "+puntaje.toString(),"Juego Finalizado",JOptionPane.OK_OPTION,JOptionPane.PLAIN_MESSAGE,null,opciones,opciones[0]);
		nuevo_tablero();
	}
	
	public static void main( String[] pArgs) {
		ventana_principal interfaz= new ventana_principal();
		interfaz.setVisible(true);
		
	}

}
