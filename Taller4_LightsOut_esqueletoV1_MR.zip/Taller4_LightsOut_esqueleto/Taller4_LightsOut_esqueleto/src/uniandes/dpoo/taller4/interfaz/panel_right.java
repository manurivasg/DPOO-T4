package uniandes.dpoo.taller4.interfaz;


import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class panel_right extends JPanel implements ActionListener {
	
	private final String NUEVO = "Nuevo";
	private final String REINICIAR = "Reiniciar";
	private final String TOP10 = "Top 10";
	private final String CAMBIAR = "Cambiar jugador";
	
	private ventana_principal vp;
	
	
	public panel_right(ventana_principal vp) {
		
		this.vp = vp;
		
		setLayout(new GridLayout(4,1));
		
		JButton nuevo = new JButton(NUEVO);
		nuevo.addActionListener(this);
		add(nuevo);
		
		JButton reiniciar = new JButton(REINICIAR);
		reiniciar.addActionListener(this);
		add(reiniciar);
		
		JButton top = new JButton(TOP10);
		top.addActionListener(this);
		add(top);
		
		JButton jugador = new JButton(CAMBIAR);
		jugador.addActionListener(this);
		add(jugador);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String comando = e.getActionCommand();
		
		if (comando.equals(NUEVO)) {
			vp.nuevo_tablero();
		}
		
		if (comando.equals(REINICIAR)) {
			vp.reiniciar();
		}
		
		if (comando.equals(CAMBIAR)) {
			vp.cambiar_jugador();
		}
		
	}

}
