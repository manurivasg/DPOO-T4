package uniandes.dpoo.taller4.interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class panel_up extends JPanel implements ActionListener {
	
	private JComboBox combo_tamano;
	private ButtonGroup botones_dificultad;
	private JLabel label_dif;
	private JLabel label_tam;
	private ventana_principal vp;
	private int tamano_seleccionado;
	private String dificultad_seleccionada;
	
	private static final String size1 = "5X5";
	private static final String size2 = "6X6";
	private static final String size3 = "7X7";
	private static final String FACIL = "Facil";
	private static final String MEDIO = "Medio";
	private static final String DIFICIL = "Dificil";

	public panel_up(ventana_principal vp){
		
	this.vp = vp;
	tamano_seleccionado = 5;
	dificultad_seleccionada = FACIL;
	
	setLayout(new GridLayout(1,6));
	
	label_tam = new JLabel("Tamaño:");
	add(label_tam);
	
	String[]tamanos = {size1,size2,size3};
	combo_tamano = new JComboBox(tamanos);
	combo_tamano.addActionListener(this);

	add(combo_tamano);
	
	label_dif = new JLabel("Dificultad:");
	add(label_dif);
	
	botones_dificultad = new ButtonGroup();
	
	JRadioButton facil = new JRadioButton(FACIL);
	add(facil);
	facil.addActionListener(this);
	botones_dificultad.add(facil);
	
	JRadioButton medio = new JRadioButton(MEDIO);
	add(medio);
	medio.addActionListener(this);
	botones_dificultad.add(medio);
	
	JRadioButton dificil = new JRadioButton(DIFICIL);
	add(dificil);
	dificil.addActionListener(this);
	botones_dificultad.add(dificil);
	
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		
		String comando = e.getActionCommand();
		
		if (e.getSource() == combo_tamano) {
			String opcion = (String) combo_tamano.getSelectedItem();
			int tamano = 0;
			
			if (opcion.equals(size1)) {
				tamano = 5;
			}
			
			else if (opcion.equals(size2)) {
				tamano = 6;
			}
			
			else if (opcion.equals(size3)) {
				tamano = 7;
			}
			
			tamano_seleccionado = tamano;

		}
		
	if ((comando.equals(FACIL))||(comando.equals(MEDIO))||(comando.equals(DIFICIL))) 
	{
		dificultad_seleccionada = comando;
	}
		
	}
	
	public int getTamano_seleecionado() {
		return tamano_seleccionado;
	}
	
	public String getDificultad_seleccionada() {
		return dificultad_seleccionada;
	}


    public int getTamano_selecionado() {
        return 0;
    }

}
