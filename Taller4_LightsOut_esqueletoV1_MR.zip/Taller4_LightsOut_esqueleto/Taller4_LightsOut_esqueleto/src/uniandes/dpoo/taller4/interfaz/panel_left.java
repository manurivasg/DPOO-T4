package uniandes.dpoo.taller4.interfaz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JPanel;

public class panel_left extends JPanel implements MouseListener {
	
	private boolean[][] tablero;
	private ventana_principal vp;
	private boolean hayTablero;
	
	public panel_left(boolean[][] tablero, ventana_principal vp) {
		hayTablero = false;
		this.tablero = tablero;
		this.vp = vp;
		addMouseListener( this );
		
	}

	@Override
	public void paint(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.LIGHT_GRAY);
		g2d.fillRect(0, 0, getWidth(), getHeight());
		
		int deltax =  (getWidth()/vp.getTamano());
		int deltay =  (getHeight()/vp.getTamano());
		
		g2d.setColor(Color.BLACK);
		int x = 0;
		int y =  0;
		
		if (hayTablero) {
		for (int i = 0; i<vp.getTamano(); i++) {
			for (int j = 0; j<vp.getTamano();j ++) {
				if (tablero[i][j] == true) {
					g2d.setColor(Color.YELLOW);
				}
				else {
					g2d.setColor(Color.BLACK);
				}
				
				g2d.fillRoundRect(x, y, deltax, deltay, 20, 20);
				x += deltax;
			
			
		}
			x = 0;
			y += deltay;

		}
	}
		
		else {
			for (int i = 0; i < vp.getTamano(); i ++) {
				for (int j = 0; j<vp.getTamano();j ++) {			
					g2d.fillRoundRect(x, y, deltax, deltay, 20, 20);
					x += deltax;
				
			}
				x = 0;
				y += deltay;
			
			}
		}
	}
	
	public void nuevo_tablero( boolean[][] tablero) {
		hayTablero = true;
		this.tablero = tablero;
		repaint();
	}
	
	private int[] convertirCoordenadasACasilla(int x, int y)
	{
	int ladoTablero = vp.getTamano();
	int altoPanelTablero = getHeight();
	int anchoPanelTablero = getWidth();
	int altoCasilla = altoPanelTablero / ladoTablero;
	int anchoCasilla = anchoPanelTablero / ladoTablero;
	int fila = (int) (y / altoCasilla);
	int columna = (int) (x / anchoCasilla);
	return new int[] { fila, columna };
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		if (hayTablero) {
			int clickX = e.getX();
			int clickY = e.getY();
			int[] casilla = convertirCoordenadasACasilla(clickX, clickY);
			vp.jugar(casilla[0], casilla[1]);
			
			
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
